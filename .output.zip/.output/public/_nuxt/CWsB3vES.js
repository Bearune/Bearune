import{_ as r,o,c as t,q as s}from"./CN05XVOD.js";const c={};function n(e,a){return o(),t("tr",null,[s(e.$slots,"default")])}const _=r(c,[["render",n]]);export{_ as default};
