import{_ as o,o as r,c as t,q as s}from"./CN05XVOD.js";const a={};function c(e,n){return r(),t("table",null,[s(e.$slots,"default")])}const _=o(a,[["render",c]]);export{_ as default};
