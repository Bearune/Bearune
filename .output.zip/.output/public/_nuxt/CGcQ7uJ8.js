import{k as n,a8 as e}from"./CN05XVOD.js";const t=n({name:"DocumentDrivenNotFound",render(){return e("div","Document not found")}});export{t as default};
