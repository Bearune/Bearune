import{_ as o,o as r,c as s,q as t}from"./CN05XVOD.js";const c={};function n(e,a){return r(),s("p",null,[t(e.$slots,"default")])}const _=o(c,[["render",n]]);export{_ as default};
